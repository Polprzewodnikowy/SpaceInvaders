Space Invaders v0.8

Avaiable arguments:

	-help - View help
	-vsync - Enable vertical sync, overrides framelimit settings
	-fr [number] - Set frame limit from 30 to 120 (default 60)

https://github.com/Polprzewodnikowy/SpaceInvaders